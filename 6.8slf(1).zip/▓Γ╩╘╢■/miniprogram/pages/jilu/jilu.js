Page({
  data:{
    date:"",
    data2:"",
    xianshi:""
  },
  onLoad:function(options){
    var thisPage = this;
    var d = new Date()
    var date ="打卡时间："+ d.getFullYear()+'年'+d.getMonth()+'月'+d.getDate()+'日'+d.getHours()+'点'+d.getMinutes()+'分'+d.getSeconds()+'秒'
    this.setData({
      date:date
    })
    wx.cloud.database().collection('userInfo')
      .add({   
        data:{
          name:"slf",
          qiandao:date,
        }
      })
      .then(res =>{
        console.log("success",res)
      })
      .catch(res => {
        console.log("fail",res)
      })

      wx.cloud.database().collection('userInfo')//我的数据表的名称是student
      .get({   
        success(res){
            console.log(res)          
            thisPage.setData({
              xianshi:res.data,
            }) 
            console.log(xianshi)  
        },
        fail(err){
          console.log(err)
        },
      })
  },
  time(){
    var d2 = new Date()
    var date2 ="签退时间："+ d2.getFullYear()+'年'+d2.getMonth()+'月'+d2.getDate()+'日'+d2.getHours()+'点'+d2.getMinutes()+'分'+d2.getSeconds()+'秒' 
    this.setData({
      date:this.data.date+" \n "+date2,
      date2:date2
    })
  }
})
