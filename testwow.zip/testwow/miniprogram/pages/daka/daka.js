Page({
  data: {
    timer:"",
    hours: '0' + 0,   // 时
    minute: '0' + 0,   // 分
    second: '0' + 0 ,   // 秒
    date:[],
    date2:[],
    flag:false
  },
  start(){
    const that = this
    var hours = that.data.hours
    var minute = that.data.minute
    var second = that.data.second
    var d = new Date()
    var date ="打卡时间："+ d.getFullYear()+'年'+d.getMonth()+'月'+d.getDate()+'日'+d.getHours()+'点'+d.getMinutes()+'分'+d.getSeconds()+'秒'
    console.log(date)
    this.setData({
      date:date,
      flag:true
    })
      // 调用函数
    that.data.timer = setInterval(function () {  // 设置定时器
        second++
        if (second >= 60) {
            second = 0  //  大于等于60秒归零
            minute++
            if (minute >= 60) {
                minute = 0  //  大于等于60分归零
                hours++
                if (hours < 10) {
                    // 少于10补零
                    that.setData({
                        hours: '0' + hours
                    })
                } else {
                    that.setData({
                        hours: hours
                    })
                }
            }
            if (minute < 10) {
                // 少于10补零
                that.setData({
                    minute: '0' + minute
                })
            } else {
                that.setData({
                    minute: minute
                })
            }
        }
        if (second < 10) {
            // 少于10补零
            that.setData({
                second: '0' + second
            })
        } else {
            that.setData({
                second: second
            })
        }
    }, 1000)
},
  Start(){
      this.start()
      wx.showToast({
        title: '打卡成功',
      })
  },
  stop(){ 
      var d = new Date()
      var date2 ="签退时间："+ d.getFullYear()+'年'+d.getMonth()+'月'+d.getDate()+'日'+d.getHours()+'点'+d.getMinutes()+'分'+d.getSeconds()+'秒'
      this.setData({
        date2:date2,
        flag:false,
        hours: '00',
        minute: '00',
        second: '00',
      })
      console.log(this.data.date2)
      clearInterval(this.data.timer)
      wx.showToast({
        title: '签退成功',
      })
    },
  onUnload:function(){
      var thisPage = this;
      clearInterval(thisPage.data.setInterval)
      wx.cloud.database().collection('userInfo')
      .add({
          data:{
              daka:thisPage.data.date,
              qiantui:thisPage.data.date2,
      }
     })
      .then(res =>{
        console.log("success",res)
      })
      .catch(res => {
        console.log("fail",res)
      })
    }
})