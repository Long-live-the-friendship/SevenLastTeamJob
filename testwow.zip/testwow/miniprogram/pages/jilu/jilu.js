Page({
  data:{
    // date:"",
    // data2:"",
    xianshi:[],
    info:[]
  },
  onLoad:function(options){
      var thisPage = this;
      wx.cloud.database().collection('userInfo')
      .get({   
        success(res){
            console.log(res)          
            thisPage.setData({
              xianshi:res.data,
            }) 
            console.log(xianshi)  
        },
        fail(err){
          console.log(err)
        },
      })
    }
  })
