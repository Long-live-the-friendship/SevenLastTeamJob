// pages/mine/mine.js
Page({
  data:{
    open_id:"",
    userInfo:"",
  },
  login(){
    wx.getUserProfile({
      desc:'为了更好的使用小程序，请先授权',
      success:res=>{
        let user = res.userInfo
        let open_id = res.cloudID
        console.log("授权成功",res)
        this.setData({
          userInfo:user,
          open_id:open_id,
        })

      },
      fail:res=>{
        console.log("授权失败")
      }
    })
  },
  loginout(){
    this.setData({
      userInfo:""
    })
  },
  // onLoad(){  //一跳转到这个界面就开始运行
  //   var thisPage = this;
  //   // 添加
  //   wx.cloud.database().collection('userInfo')
  //     .add({   
  //       data:{
  //         open_id:thisPage.data.open_id,
          
  //       }
  //     })
  //     .then(res =>{
  //       console.log("success",res)
  //     })
  //     .catch(res => {
  //       console.log("fail",res)
  //     })
  //   }
})