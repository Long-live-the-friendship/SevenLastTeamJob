// pages/mine/mine.js
Page({
  daka: function(){
    wx.navigateTo({
      url: "/pages/daka/daka",
    })
  },
  jilu:function(){
    wx.navigateTo({
      url: "/pages/jilu/jilu",
    })
  },
  rank:function(){
    wx.navigateTo({
      url: '/pages/rank/rank',
    })
  },
  camera:function(){
    wx.navigateTo({
      url: '/pages/photo/photo',
    })
  }
})