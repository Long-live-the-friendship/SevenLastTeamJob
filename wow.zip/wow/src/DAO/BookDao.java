package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;

import View.UserInfo;

import static java.awt.SystemColor.info;

public class BookDao {
    private Connection conn;
    private PreparedStatement pst;
    private ResultSet res;
    private boolean flag;

    //查询id是否在数据库中
    public List<Info> list(){
        List<Info> list = new ArrayList<Info>();
        String sql = "select * from userinfo";
        try {
            conn= DBUtils.getConn();
            pst=conn.prepareStatement(sql);
            res=pst.executeQuery();
            while (res.next()){
                Info info=new Info();
                info.setId(res.getString("id"));
                info.setName(res.getString("name"));
                list.add(info);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtils.close(pst,conn,res);
        }
        return list;

    }
//用户注册时，将用户的相关信息插入数据库中
    public boolean addUser(Info info) {
        String sql = "insert ignore into userinfo(id,name,clocktime,ctime,count) values(?,?,?,?,?)";

        try {
            conn = DBUtils.getConn();
            pst = conn.prepareStatement(sql);
            pst.setString(1, info.getId());
            pst.setString(2, info.getName());
            pst.setString(3, info.getClocktime1());
            pst.setString(4, info.getClocktime2());
            pst.setLong(5, info.getSum());
            //String date1 = info.getClocktime1();
            int i = pst.executeUpdate();
            if (i == 0) {
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtils.close(pst, conn, res);
        }
        return true;
    }

    //将当前系统时间写入数据库
    public boolean ClockMe(Info info) {
        String sql = "UPDATE ignore userinfo set id=?,name=?,clocktime=?,ctime=?,count=?";
        try {
            conn = DBUtils.getConn();
            pst = conn.prepareStatement(sql);
            pst.setString(1, info.getId());
            pst.setString(2, info.getName());
            pst.setString(3, info.getClocktime1());
            pst.setString(4, info.getClocktime2());
            pst.setLong(5, info.getSum());
            int i = pst.executeUpdate();
            if (i == 1) {
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtils.close(pst, conn, res);
        }
        return true;
    }


    //将签退的系统时间写入数据库
    public boolean ExitMe(Info info) {
        String sql = "UPDATE ignore userinfo set id=?,name=?,clocktime=?,ctime=?,count=?";
        try {
            conn = DBUtils.getConn();
            pst = conn.prepareStatement(sql);
            pst.setString(1, info.getId());
            pst.setString(2, info.getName());
            pst.setString(3, info.getClocktime1());
            pst.setString(4, info.getClocktime2());
            pst.setLong(5, info.getSum());
            int i = pst.executeUpdate();
            if (i == 1) {
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtils.close(pst, conn, res);
        }
        return true;
    }
    //将总时长存入数据库
    public boolean Save(Info info){
        String sql = "UPDATE ignore userinfo set id=?,name=?,clocktime=?,ctime=?,count=?";
        try {
            conn = DBUtils.getConn();
            pst = conn.prepareStatement(sql);
            pst.setString(1, info.getId());
            pst.setString(2, info.getName());
            pst.setString(3, info.getClocktime1());
            pst.setString(4, info.getClocktime2());
            pst.setLong(5, info.getSum());
            int i = pst.executeUpdate();
            if (i == 1) {
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtils.close(pst, conn, res);
        }
        return true;
    }
    //排行榜
    public List<Info> sortlist() {
        List<Info> sortlist = new ArrayList<Info>();
        String sql = "SELECT * FROM  userinfo  ORDER BY count DESC";
        try {
            conn= DBUtils.getConn();
            pst=conn.prepareStatement(sql);
            res=pst.executeQuery();
            while (res.next()){
                Info info=new Info();
                info.setId(res.getString("id"));
                info.setName(res.getString("name"));
                info.setSum(res.getLong("count"));
                sortlist.add(info);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtils.close(pst,conn,res);
        }
        System.out.println("ID               姓名           时长（秒）");
        for(Info sortinfo : sortlist){
            System.out.println(sortinfo.getId()+"       "+sortinfo.getName()+"           "+sortinfo.getSum());
        }
        return sortlist;
    }
}
