package DAO;

public class Info {
    private String name;
    private String id;
    private String clocktime1;
    private String clocktime2;
    private Long sum;

    public Long getSum() {
        return sum;
    }

    public void setSum(Long sum) {
        this.sum = sum;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClocktime1() {
        return clocktime1;
    }

    public void setClocktime1(String clocktime1) {
        this.clocktime1 = clocktime1;
    }

    public String getClocktime2() {
        return clocktime2;
    }

    public void setClocktime2(String clocktime2) {
        this.clocktime2 = clocktime2;
    }

    public Info() {
    }

    public Info( String id, String name,String clocktime1, String clocktime2, Long sum) {
        this.name = name;
        this.id = id;
        this.clocktime1 = clocktime1;
        this.clocktime2 = clocktime2;
        this.sum = sum;
    }

    @Override
    public String toString() {
        return "Info{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", clocktime1='" + clocktime1 + '\'' +
                ", clocktime2='" + clocktime2 + '\'' +
                '}';
    }
}
