package View;

import Clock.GetTime;
import DAO.BookDao;
import DAO.Info;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import static java.awt.SystemColor.info;


public class UserInfo {
    private static boolean flag;
    private static String name;
    public static String id;
    public static String clock1;
    public static String clock2;
    public static long sum;

    public UserInfo() {
    }

    public void menu() throws ParseException {
        System.out.println("0.登录");
        System.out.println("1.注册");
        Scanner s = new Scanner(System.in);
        System.out.print("请输入你要进行的操作：");
        int i = s.nextInt();
        if(i==1){
            //注册
            register();
            Menu me = new Menu();
            me.show();
        }else{
            //登录
            boolean f = judge();
            if (f == flag) {
                Menu me = new Menu();
                me.show();
            }
            else {
                System.out.println("请先注册你的账号");
                register();
            }
        }
    }
//登录
    public static boolean judge() {

        Scanner sc = new Scanner(System.in);
        System.out.print("请输入账号:");
        id = sc.next();
        System.out.print("请输入姓名:");
        name = sc.next();
        BookDao dao = new BookDao();
        List<Info> list= dao.list();
        int i = 0;
        for(Info infoList : list){
            if(infoList.getId().equals(id)&&infoList.getName().equals(name)){
                System.out.println("登录成功");
                i = 1;
            }
        }
        if (i==0){
            System.out.println("请先注册");
            register();
        }
        return flag;
    }


    //注册
    public static boolean register() {
        Scanner sc = new Scanner(System.in);
        System.out.println("------------------------");
        System.out.println("-----欢迎来到注册页面-----");
        System.out.print("请输入你的专属id：");
        id = sc.nextLine();//修改了类型 String 和 把next改为nextline
        System.out.print("请输入你的昵称：");
        name = sc.nextLine();
        clock1 = "未打卡";
        clock2 = "未签退";
        sum = 0;
        Info info = new Info(id,name,clock1,clock2,sum);
        BookDao dao = new BookDao();
        boolean f = dao.addUser(info);
        if(f){
            System.out.println("注册失败");
        }
        else{
            System.out.println("注册成功");
        }
        return true;

    }
//打卡
    public static void Clockme() {
        GetTime time1 = new GetTime();
        //Scanner sc = new Scanner(System.in);
        System.out.print("打卡");
        clock1 = time1.GetTime();
        BookDao dao = new BookDao();
        Info info = new Info(id,name,clock1,clock2,sum);
        boolean flag = dao.ClockMe(info);
        if (flag) {
            System.out.println("保存失败！");
        } else {
            System.out.println("保存成功！");
        }

    }
//签退
    public static void exitme() {
        System.out.println("签退");
        GetTime time2 = new GetTime();
        clock2 = time2.GetTime();
        Info info = new Info(id,name,clock1,clock2,sum);
        BookDao dao = new BookDao();
        boolean flag = dao.ClockMe(info);
        if (flag) {
            System.out.println("保存失败！");
        } else {
            System.out.println("保存成功！");
        }

    }
    //打卡时长
    public static void TimeDiffernce() throws ParseException {
        SimpleDateFormat fo = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        long c = 0;
        System.out.println(clock1);
        System.out.println(clock2);
            try {
                if (clock1 != null && clock2 != null) {
                    Date d1 = fo.parse(clock1);
                    Date d2 = fo.parse(clock2);
                    if (d2.after(d1)) {
                        long a = d1.getTime();
                        long b = d2.getTime();
                        c = (b - a)/1000l;
                    }
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
            sum = c;
        Info info = new Info(id,name,clock1,clock2,sum);
        BookDao dao = new BookDao();
        boolean flag = dao.Save(info);
        if (flag) {
            System.out.println("保存失败！");
        } else {
            System.out.println("保存成功！");
        }
        System.out.println(c);
    }
    //排行榜
    public static void recode(){
        Info info = new Info();
        long countTime = 0;
        for(int m= 0;m < 7;m++){
            countTime+=sum;
        }
        System.out.println("在最近7次打卡记录里，你累计打卡"+countTime+"秒");
    }
}
