package View;

import DAO.BookDao;
import DAO.Info;

import java.io.DataOutput;
import java.text.ParseException;
import java.util.List;
import java.util.Scanner;

import static View.UserInfo.*;


public class Menu {
    public void show() throws ParseException {
        while (true) {
            System.out.println("--------------------");
            System.out.println("2.打卡");
            System.out.println("3.签退");
            System.out.println("4.查看打卡时长");
            System.out.println("5.查看排行榜");
            System.out.println("6.近7次打卡时长");
            System.out.println("--------------------");
            Scanner sc = new Scanner(System.in);
            System.out.print("请输入你要进行的操作：");
            int n = sc.nextInt();
            switch (n) {
                case 2:
                    Clockme();
                    break;
                case 3:
                    exitme();
                    break;
                case 4:
                    TimeDiffernce();
                    break;
                case 5:
                    BookDao dao = new BookDao();
                    List<Info> sortlist = dao.sortlist();
                    break;
                case 6:
                    recode();
                    break;
                default:
                    System.out.println("退出当前账号！");
                    System.exit(0);
                    break;
            }
        }
    }
}
