import View.UserInfo;

import java.text.ParseException;

class Main {
    public static void main(String[] args) throws ParseException {
        UserInfo info = new UserInfo();
        info.menu();
    }
}
