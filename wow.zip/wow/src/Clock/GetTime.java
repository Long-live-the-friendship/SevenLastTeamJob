package Clock;

import java.text.SimpleDateFormat;
import java.util.Date;

public class GetTime {
    public GetTime() {
    }

    public String GetTime() {
        Date date = new Date();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String str = simpleDateFormat.format(date);
        return str;
    }

}