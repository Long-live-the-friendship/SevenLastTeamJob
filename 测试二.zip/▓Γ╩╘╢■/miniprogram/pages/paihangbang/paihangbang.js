Page({
  data:{
    date:[]
  },
  onLoad:function(options){
    var d = new Date()
    var date = "打卡时间："+ d.getFullYear()+'年'+d.getMonth()+'月'+d.getDate()+'日'+d.getHours()+'点'+d.getMinutes()+'分'+d.getSeconds()+'秒'
    date=this.data.date+date
    console.log(date)
  //   var dd = d.getFullYear()
  //   console.log(dd)
  //   date=this.data.date+dd
  //   this.setData({
  //     date:date
  //   })
  // }
  }
})