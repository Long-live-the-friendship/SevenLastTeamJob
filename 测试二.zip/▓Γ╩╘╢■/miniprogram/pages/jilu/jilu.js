Page({
  data:{
    date:""
  },
  onLoad:function(options){
    var d = new Date()
    var date = d.getFullYear()+'年'+d.getMonth()+'月'+d.getDate()+'日'+d.getHours()+'点'+d.getMinutes()+'分'+d.getSeconds()+'秒'
    console.log(date)
    this.setData({
      date:date
    })
  }
})
